<p align="center">
    <img src="https://github.com/nifty-site-manager/nsm-snap/blob/master/signature.png" width='120'/>
</p>

=====

Copyright (c) 2015-present [Nicholas Ham](https://n-ham.com).

This is an official (gitlab) repository for nifty-site-manager, a cross-platform git-like and LaTeX-like command-line site manager.


Website:
\[[official](https://nifty-site-manager.com)\] \[[bitbucket](https://nifty-site-manager.bitbucket.io)\] \[[github](https://nifty-site-manager.github.io)\] \[[gitlab](https://nifty-site-manager.gitlab.io)\] \[[archive.org](https://web.archive.org/web/https://www.nifty-site-manager.com/)\]

Repositories:
\[[bitbucket](https://bitbucket.com/nifty-site-manager/nsm)\] \[[github](https://github.com/nifty-site-manager/nsm)\] \[[gitlab](https://gitlab.com/nifty-site-manager/nsm)\] \[[archive.org](https://web.archive.org/web/https://gitlab.com/nifty-site-manager/nsm)\]

