#include "PageBuilder.h"

std::atomic<long long int> sys_counter;

bool is_whitespace(const std::string& str)
{
    for(size_t i=0; i<str.size(); i++)
        if(str[i] != ' ' && str[i] != '\t')
            return 0;

    return 1;
}

std::string into_whitespace(const std::string& str)
{
    std::string whitespace = "";

    for(size_t i=0; i<str.size(); i++)
    {
        if(str[i] == '\t')
            whitespace += "\t";
        else
            whitespace += " ";
    }

    return whitespace;
}

bool run_scripts(std::ostream &os, const std::string& scriptsPath)
{
    sys_counter = sys_counter%1000000000000000000;

    std::string scriptPath,
                output_filename;

    int lineNo = 0;

    if(std::ifstream(scriptsPath))
    {
        std::ifstream ifs(scriptsPath);

        while(getline(ifs, scriptPath))
        {
            lineNo++;

            if(!scriptPath.size() || scriptPath[0] == '#' || is_whitespace(scriptPath))
                continue;

            /*
                If we do the following can't do eg.
                    ./script.ext input-params
                    python program.py
                    etc.
            */
            /*if(!std::ifstream(scriptPath))
            {
                std::cout << "error: nsm.cpp: " << scriptsPath << ": script " << scriptPath << " does not exist" << std::endl;
                return 1;
            }*/

            #if defined _WIN32 || defined _WIN64
                if(unquote(scriptPath).substr(0, 2) == "./")
                    scriptPath = unquote(scriptPath).substr(2, unquote(scriptPath).size()-2);
            #else  //unix
                //scriptPath = "./" + scriptPath;
            #endif

            output_filename = scriptsPath + ".out" + std::to_string(sys_counter++);

            //checks whether we're running from flatpak
            if(std::ifstream("/.flatpak-info"))
            {
                int result = system(("flatpak-spawn --host bash -c " + quote(scriptPath) + " > " + output_filename).c_str());

                std::ifstream ifxs(output_filename);
                std::string str;
                while(getline(ifxs, str))
                    os << str << std::endl;
                ifxs.close();
                Path("./", output_filename).removePath();

                if(result)
                {
                    os << "error: nsm.cpp: " << scriptsPath << ": line " << lineNo << ": '" << unquote(scriptPath) << "' failed" << std::endl;
                    return 1;
                }
            }
            else
            {
                int result = system((scriptPath + " > " + output_filename).c_str());

                std::ifstream ifxs(output_filename);
                std::string str;
                while(getline(ifxs, str))
                    os << str << std::endl;
                ifxs.close();
                Path("./", output_filename).removePath();

                if(result)
                {
                    os << "error: nsm.cpp: " << scriptsPath << ": line " << lineNo << ": '" << unquote(scriptPath) << "' failed" << std::endl;
                    return 1;
                }
            }
        }

        ifs.close();
    }

    return 0;
}

PageBuilder::PageBuilder(std::set<PageInfo>* Pages, std::mutex* OS_mtx, const Directory& ContentDir, const Directory& SiteDir, const std::string& ContentExt, const std::string& PageExt, const Path& DefaultTemplate)
{
    sys_counter = 0;
    pages = Pages;
    os_mtx = OS_mtx;
    contentDir = ContentDir;
    siteDir = SiteDir;
    contentExt = ContentExt;
    pageExt = PageExt;
    defaultTemplate = DefaultTemplate;
}

int PageBuilder::build(const PageInfo &PageToBuild, std::ostream& os)
{
    sys_counter = sys_counter%1000000000000000000;
    pageToBuild = PageToBuild;

    //os_mtx->lock();
    //os << std::endl;
    //os_mtx->unlock();

    //ensures content and template files exist
    if(!std::ifstream(pageToBuild.contentPath.str()))
    {
        os_mtx->lock();
        os << "error: cannot build " << pageToBuild.pagePath << " as content file " << pageToBuild.contentPath << " does not exist" << std::endl;
        os_mtx->unlock();
        return 1;
    }
    if(!std::ifstream(pageToBuild.templatePath.str()))
    {
        os_mtx->lock();
        os << "error: cannot build " << pageToBuild.pagePath << " as template file " << pageToBuild.templatePath << " does not exist." << std::endl;
        os_mtx->unlock();
        return 1;
    }

    //checks for pre-build scripts
    Path prebuildScripts = pageToBuild.contentPath;
    prebuildScripts.file = prebuildScripts.file.substr(0, prebuildScripts.file.find_first_of('.')) + ".pre-build.scripts";
    if(run_scripts(os, prebuildScripts.str()))
        return 1;

    //os_mtx->lock();
    //os << "building page " << pageToBuild.pagePath << std::endl;
    //os_mtx->unlock();

    //makes sure variables are at default values
    codeBlockDepth = htmlCommentDepth = 0;
    indentAmount = "";
    contentAdded = 0;
    processedPage.clear();
    processedPage.str(std::string());
    pageDeps.clear();
    strings.clear();
    contentAdded = 0;

    //adds content and template paths to dependencies
    pageDeps.insert(pageToBuild.contentPath);
    pageDeps.insert(pageToBuild.templatePath);

    //opens up template file to start parsing from
    std::ifstream ifs(pageToBuild.templatePath.str());

    //creates anti-deps of page template set
    std::set<Path> antiDepsOfReadPath;

    //starts read_and_process from templatePath
    int result = read_and_process(1, ifs, pageToBuild.templatePath, antiDepsOfReadPath, processedPage, os);

    ifs.close();

    if(result == 0)
    {
        //ensures @inputcontent was found inside template dag
        if(!contentAdded)
        {
            os_mtx->lock();
            os << "error: content file " << pageToBuild.contentPath << " has not been used as a dependency within template file " << pageToBuild.templatePath << " or any of its dependencies" << std::endl;
            os_mtx->unlock();
            return 1;
        }

        //makes sure page file exists
        pageToBuild.pagePath.ensurePathExists();

        //makes sure we can write to page file
        chmod(pageToBuild.pagePath.str().c_str(), 0644);

        //writes processed page to page file
        std::ofstream pageStream(pageToBuild.pagePath.str());
        pageStream << processedPage.str() << "\n";
        pageStream.close();

        //makes sure user can't accidentally write to page file
        chmod(pageToBuild.pagePath.str().c_str(), 0444);

        //gets path for storing page information
        Path pageInfoPath = pageToBuild.pagePath.getInfoPath();

        //makes sure page info file exists
        pageInfoPath.ensurePathExists();

        //makes sure we can write to info file_
        chmod(pageInfoPath.str().c_str(), 0644);

        //writes page info file
        std::ofstream infoStream(pageInfoPath.str());
        infoStream << dateTimeInfo.currentTime() << " " << dateTimeInfo.currentDate() << "\n";
        infoStream << this->pageToBuild << "\n\n";
        for(auto pageDep=pageDeps.begin(); pageDep != pageDeps.end(); pageDep++)
            infoStream << *pageDep << "\n";
        infoStream.close();

        //makes sure user can't accidentally write to info file
        chmod(pageInfoPath.str().c_str(), 0444);

        //os_mtx->lock();
        //os << "page build successful" << std::endl;
        //os_mtx->unlock();
    }

    //checks for post-build scripts
    Path postbuildScripts = pageToBuild.contentPath;
    postbuildScripts.file = postbuildScripts.file.substr(0, postbuildScripts.file.find_first_of('.')) + ".post-build.scripts";
    if(run_scripts(os, postbuildScripts.str()))
        return 0; //should a page be listed as failing to build if the post-build script fails?

    return result;
}

//parses istream 'is' whilst writing processed version to ostream 'os' with error ostream 'eos'
int PageBuilder::read_and_process(const bool& indent, std::istream& is, const Path& readPath, std::set<Path> antiDepsOfReadPath, std::ostream& os, std::ostream& eos)
{
    //adds read path to anti dependencies of read path
    if(std::ifstream(readPath.str()))
        antiDepsOfReadPath.insert(readPath);

    std::string baseIndentAmount = indentAmount;
    if(!indent) // not sure if this is needed?
        baseIndentAmount = "";
    int baseCodeBlockDepth = codeBlockDepth;

    int lineNo = 0,
        openCodeLineNo = 0;
    std::string inLine;
    while(getline(is, inLine))
    {
        lineNo++;

        if(lineNo > 1)
        {
            indentAmount = baseIndentAmount;
            if(codeBlockDepth)
                os << "\n";
            else
                os << "\n" << baseIndentAmount;
        }

        for(size_t linePos=0; linePos<inLine.length();)
        {
            if(inLine[linePos] == '\\') //checks whether to escape
            {
                linePos++;
                /*
                    see http://dev.w3.org/html5/html-author/charref for
                    more character references than you could ever need!
                */
                switch(inLine[linePos])
                {
                    case '~':
                        os << "&tilde;";
                        linePos++;
                        if(indent)
                            indentAmount += std::string(7, ' ');
                        break;
                    case '!':
                        os << "&excl;";
                        linePos++;
                        if(indent)
                            indentAmount += std::string(6, ' ');
                        break;
                    case '@':
                        os << "&commat;";
                        linePos++;
                        if(indent)
                            indentAmount += std::string(8, ' ');
                        break;
                    case '#':
                        os << "&num;";
                        linePos++;
                        if(indent)
                            indentAmount += std::string(5, ' ');
                        break;
                    /*case '$': //MUST HAVE MATHJAX HANDLE THIS
                        os << "&dollar;";
                        linePos++;
                        indentAmount += string(8, ' ');
                        break;*/
                    case '%':
                        os << "&percnt;";
                        linePos++;
                        if(indent)
                            indentAmount += std::string(8, ' ');
                        break;
                    case '^':
                        os << "&Hat;";
                        linePos++;
                        if(indent)
                            indentAmount += std::string(5, ' ');
                        break;
                    /*case '&': //SEEMS TO BREAK SOME VALID JAVASCRIPT CODE
                                //CHECK DEVELOPERS PERSONAL SITE GENEALOGY PAGE
                                //FOR EXAMPLE (SEARCH FOR \&)
                        os << "&amp;";
                        linePos++;
                        if(indent)
                            indentAmount += std::string(5, ' ');
                        break;*/
                    case '*':
                        os << "&ast;";
                        linePos++;
                        if(indent)
                            indentAmount += std::string(5, ' ');
                        break;
                    case '?':
                        os << "&quest;";
                        linePos++;
                        if(indent)
                            indentAmount += std::string(7, ' ');
                        break;
                    case '<':
                        os << "&lt;";
                        linePos++;
                        if(indent)
                            indentAmount += std::string(4, ' ');
                        break;
                    case '>':
                        os << "&gt;";
                        linePos++;
                        if(indent)
                            indentAmount += std::string(4, ' ');
                        break;
                    default:
                        os << "\\";
                        if(indent)
                            indentAmount += " ";
                }
            }
            else if(inLine[linePos] == '<') //checks about code blocks and html comments opening
            {
                //checks whether we're going down code block depth
                if(htmlCommentDepth == 0 && inLine.substr(linePos+1, 4) == "/pre")
                {
                    codeBlockDepth--;
                    if(codeBlockDepth < baseCodeBlockDepth)
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": </pre> close tag has no preceding <pre*> open tag." << std::endl;
                        os_mtx->unlock();
                        return 1;
                    }
                }

                //checks whether to escape <
                if(codeBlockDepth > 0 && inLine.substr(linePos+1, 4) != "code" && inLine.substr(linePos+1, 5) != "/code")
                {
                    os << "&lt;";
                    if(indent)
                        indentAmount += into_whitespace("&lt;");
                }
                else
                {
                    os << '<';
                    if(indent)
                        indentAmount += " ";
                }

                //checks whether we're going up code block depth
                if(htmlCommentDepth == 0 && inLine.substr(linePos+1, 3) == "pre")
                {
                    if(codeBlockDepth == baseCodeBlockDepth)
                        openCodeLineNo = lineNo;
                    codeBlockDepth++;
                }

                //checks whether we're going up html comment depth
                if(inLine.substr(linePos+1, 3) == "!--")
                    htmlCommentDepth++;

                linePos++;
            }
            else if(inLine[linePos] == '-') //checks about html comments closing
            {
                //checks whether we're going down html depth
                if(inLine.substr(linePos+1, 2) == "->")
                    htmlCommentDepth--;

                os << '-';
                if(indent)
                    indentAmount += " ";
                linePos++;
            }
            else if(inLine[linePos] == '@') //checks for commands
            {
                if(linePos > 0 && inLine[linePos-1] == '\\')
                {
                    os << '@';
                    if(indent)
                        indentAmount += " ";
                    linePos++;
                }
                else if(inLine.substr(linePos, 13) == "@inputcontent")
                {
                    contentAdded = 1;
                    std::string replaceText = "@input(" + quote(pageToBuild.contentPath.str()) + ")";
                    inLine.replace(linePos, 13, replaceText);
                }
                else if(inLine.substr(linePos, 10) == "@inputhead")
                {
                    Path headPath = pageToBuild.contentPath;
                    headPath.file = headPath.file.substr(0, headPath.file.find_first_of('.')) + ".head";
                    if(std::ifstream(headPath.str()))
                    {
                        std::string replaceText = "@input(" + quote(headPath.str()) + ")";
                        inLine.replace(linePos, 10, replaceText);
                    }
                    else
                        inLine.replace(linePos, 10, "");
                }
                else if(inLine.substr(linePos, 7) == "@input(" || inLine.substr(linePos, 8) == "@input*(")
                {
                    linePos+=std::string("@input").length();
                    std::string inputPathStr;

                    if(inLine[linePos] == '*')
                    {
                        parseParams = 1;
                        linePos++;
                    }
                    else
                        parseParams = 0;

                    linePos++;

                    if(read_path(inputPathStr, linePos, inLine, readPath, lineNo, "@input()", eos) > 0)
                        return 1;

                    if(parseParams)
                    {
                        std::istringstream iss(inputPathStr);
                        oss.str("");
                        oss.clear();

                        if(read_and_process(0, iss, Path("", "input path"), antiDepsOfReadPath, oss, eos) > 0)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }

                        inputPathStr = oss.str();
                    }

                    Path inputPath;
                    inputPath.set_file_path_from(inputPathStr);
                    pageDeps.insert(inputPath);

                    if(inputPath == pageToBuild.contentPath)
                        contentAdded = 1;

                    //ensures insert file exists
                    if(!std::ifstream(inputPathStr))
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": inputting file " << inputPath << " failed as path does not exist" << std::endl;
                        os_mtx->unlock();
                        return 1;
                    }
                    //ensures insert file isn't an anti dep of read path
                    if(antiDepsOfReadPath.count(inputPath))
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": inputting file " << inputPath << " would result in an input loop" << std::endl;
                        os_mtx->unlock();
                        return 1;
                    }

                    std::ifstream ifs(inputPath.str());

                    //adds insert file
                    if(read_and_process(1, ifs, inputPath, antiDepsOfReadPath, os, eos) > 0)
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                        os_mtx->unlock();
                        return 1;
                    }
                    //indent amount updated inside read_and_process

                    ifs.close();
                }
                else if(inLine.substr(linePos, 5) == "@dep(" || inLine.substr(linePos, 6) == "@dep*(")
                {
                    linePos+=std::string("@dep").length();
                    std::string depPathStr;

                    if(inLine[linePos] == '*')
                    {
                        parseParams = 1;
                        linePos++;
                    }
                    else
                        parseParams = 0;

                    linePos++;

                    if(read_path(depPathStr, linePos, inLine, readPath, lineNo, "@dep()", eos) > 0)
                        return 1;

                    if(parseParams)
                    {
                        std::istringstream iss(depPathStr);
                        oss.str("");
                        oss.clear();

                        if(read_and_process(0, iss, Path("", "dependency path"), antiDepsOfReadPath, oss, eos) > 0)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }

                        depPathStr = oss.str();
                    }

                    Path depPath;
                    depPath.set_file_path_from(depPathStr);
                    pageDeps.insert(depPath);

                    if(depPath == pageToBuild.contentPath)
                        contentAdded = 1;

                    if(!std::ifstream(depPathStr))
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": @dep(" << quote(depPathStr) << ") failed as dependency does not exist" << std::endl;
                        os_mtx->unlock();
                        return 1;
                    }
                }
                else if(inLine.substr(linePos, 8) == "@script(" || inLine.substr(linePos, 9) == "@script*(")
                {
                    linePos+=std::string("@script").length();
                    std::string scriptPathStr;
                    std::string output_filename = ".@scriptoutput" + std::to_string(sys_counter++);

                    if(inLine[linePos] == '*')
                    {
                        parseParams = 1;
                        linePos++;
                    }
                    else
                        parseParams = 0;

                    linePos++;

                    if(read_path(scriptPathStr, linePos, inLine, readPath, lineNo, "@script()", eos) > 0)
                        return 1;

                    if(parseParams)
                    {
                        std::istringstream iss(scriptPathStr);
                        oss.str("");
                        oss.clear();

                        if(read_and_process(0, iss, Path("", "script path"), antiDepsOfReadPath, oss, eos) > 0)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }

                        scriptPathStr = oss.str();
                    }

                    #if defined _WIN32 || defined _WIN64
                        if(unquote(scriptPathStr).substr(0, 2) == "./")
                            scriptPathStr = unquote(scriptPathStr).substr(2, unquote(scriptPathStr).size()-2);
                    #else  //unix
                    #endif

                    Path scriptPath;
                    if(unquote(scriptPathStr).substr(0, 2) == "./")
                        scriptPath.set_file_path_from(unquote(unquote(scriptPathStr).substr(2, unquote(scriptPathStr).size()-2)));
                    else
                        scriptPath.set_file_path_from(unquote(scriptPathStr));
                    pageDeps.insert(scriptPath);

                    if(!std::ifstream(scriptPath.str()))
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": @script(" << quote(scriptPathStr) << ") failed as script does not exist" << std::endl;
                        os_mtx->unlock();
                        return 1;
                    }

                    //checks whether we're running from flatpak
                    if(std::ifstream("/.flatpak-info"))
                    {
                        int result = system(("flatpak-spawn --host bash -c " + quote(scriptPathStr) + " > " + output_filename).c_str());
                        //int result = system(("flatpak-spawn --host bash -c \"'" + sys_call + "'\" > " + output_filename).c_str()); //doesn't work on windows

                        std::ifstream ifs(output_filename);
                        std::string str;
                        os_mtx->lock();
                        while(getline(ifs, str))
                            eos << str << std::endl;
                        os_mtx->unlock();
                        ifs.close();

                        Path("./", output_filename).removePath();

                        //need sys_call quoted weirdly here for script paths containing spaces
                        if(result)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": @script(" << quote(scriptPathStr) << ") failed" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }
                    }
                    else //sys_call has to be quoted for script paths containing spaces //doesn't work on windows!!
                    {
                        int result = system((scriptPathStr + " > " + output_filename).c_str());
                        //int result = system((quote(sys_call) + " > " + output_filename).c_str()); //doesn't work on windows!!

                        std::ifstream ifs(output_filename);
                        std::string str;
                        os_mtx->lock();
                        while(getline(ifs, str))
                            eos << str << std::endl;
                        os_mtx->unlock();
                        ifs.close();

                        Path("./", output_filename).removePath();

                        if(result)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": @script(" << quote(scriptPathStr) << ") failed" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }
                    }
                }
                else if(inLine.substr(linePos, 14) == "@scriptoutput(" || inLine.substr(linePos, 15) == "@scriptoutput*(")
                {
                    linePos+=std::string("@scriptoutput").length();
                    std::string scriptPathStr;
                    std::string output_filename = ".@scriptoutput" + std::to_string(sys_counter++);

                    if(inLine[linePos] == '*')
                    {
                        parseParams = 1;
                        linePos++;
                    }
                    else
                        parseParams = 0;

                    linePos++;

                    if(read_path(scriptPathStr, linePos, inLine, readPath, lineNo, "@scriptoutput()", eos) > 0)
                        return 1;

                    if(parseParams)
                    {
                        std::istringstream iss(scriptPathStr);
                        oss.str("");
                        oss.clear();

                        if(read_and_process(0, iss, Path("", "script path"), antiDepsOfReadPath, oss, eos) > 0)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }

                        scriptPathStr = oss.str();
                    }

                    #if defined _WIN32 || defined _WIN64
                        if(unquote(scriptPathStr).substr(0, 2) == "./")
                            scriptPathStr = unquote(scriptPathStr).substr(2, unquote(scriptPathStr).size()-2);
                    #else  //unix
                    #endif

                    Path scriptPath;
                    if(unquote(scriptPathStr).substr(0, 2) == "./")
                        scriptPath.set_file_path_from(unquote(unquote(scriptPathStr).substr(2, unquote(scriptPathStr).size()-2)));
                    else
                        scriptPath.set_file_path_from(unquote(scriptPathStr));
                    pageDeps.insert(scriptPath);

                    if(scriptPath == pageToBuild.contentPath)
                        contentAdded = 1;

                    if(!std::ifstream(scriptPath.str()))
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": @scriptoutput(" << quote(scriptPathStr) << ") failed as script does not exist" << std::endl;
                        os_mtx->unlock();
                        return 1;
                    }

                    //checks whether we're running from flatpak
                    if(std::ifstream("/.flatpak-info"))
                    {
                        //need sys_call quoted weirdly here for script paths containing spaces (doesn't work on windows!!)
                        //if(system(("flatpak-spawn --host bash -c \"'" + sys_call + "'\" > " + output_filename).c_str()))
                        if(system(("flatpak-spawn --host bash -c " + quote(scriptPathStr) + " > " + output_filename).c_str()))
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": @scriptoutput(" << quote(scriptPathStr) << ") failed" << std::endl;
                            eos << "       see " << quote(output_filename) << " for pre-error script output" << std::endl;
                            os_mtx->unlock();
                            //Path("./", output_filename).removePath();
                            return 1;
                        }
                    }
                    //else if(system((quote(sys_call) + " > " + output_filename).c_str())) //sys_call has to be quoted for script paths containing spaces //doesn't work on windows!!
                    else if(system((scriptPathStr + " > " + output_filename).c_str()))
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": @scriptoutput(" << quote(scriptPathStr) << ") failed" << std::endl;
                        eos << "       see " << quote(output_filename) << " for pre-error script output" << std::endl;
                        os_mtx->unlock();
                        //Path("./", output_filename).removePath();
                        return 1;
                    }

                    std::ifstream ifs(output_filename);

                    //indent amount updated inside read_and_process
                    if(read_and_process(1, ifs, Path("", output_filename), antiDepsOfReadPath, os, eos) > 0)
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": failed to process output of script '" << scriptPathStr << "'" << std::endl;
                        os_mtx->unlock();
                        //Path("./", output_filename).removePath();
                        return 1;
                    }

                    ifs.close();

                    Path("./", output_filename).removePath();
                }
                else if(inLine.substr(linePos, 8) == "@system(" || inLine.substr(linePos, 9) == "@system*(")
                {
                    linePos+=std::string("@system").length();
                    std::string sys_call;
                    std::string output_filename = ".@systemoutput" + std::to_string(sys_counter++);

                    if(inLine[linePos] == '*')
                    {
                        parseParams = 1;
                        linePos++;
                    }
                    else
                        parseParams = 0;

                    linePos++;

                    if(read_sys_call(sys_call, linePos, inLine, readPath, lineNo, "@system()", eos) > 0)
                        return 1;

                    if(parseParams)
                    {
                        std::istringstream iss(sys_call);
                        oss.str("");
                        oss.clear();

                        if(read_and_process(0, iss, Path("", "system call"), antiDepsOfReadPath, oss, eos) > 0)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }

                        sys_call = oss.str();
                    }

                    #if defined _WIN32 || defined _WIN64
                        if(unquote(sys_call).substr(0, 2) == "./")
                            sys_call = unquote(sys_call).substr(2, unquote(sys_call).size()-2);
                    #else  //unix
                    #endif

                    //checks whether we're running from flatpak
                    if(std::ifstream("/.flatpak-info"))
                    {
                        int result = system(("flatpak-spawn --host bash -c " + quote(sys_call) + " > " + output_filename).c_str());

                        std::ifstream ifs(output_filename);
                        std::string str;
                        os_mtx->lock();
                        while(getline(ifs, str))
                            eos << str << std::endl;
                        os_mtx->unlock();
                        ifs.close();

                        Path("./", output_filename).removePath();

                        //need sys_call quoted here for cURL to work
                        if(result)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": @system(" << quote(sys_call) << ") failed" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }
                    }
                    else //sys_call has to be unquoted for cURL to work
                    {
                        int result = system((sys_call + " > " + output_filename).c_str());

                        std::ifstream ifs(output_filename);
                        std::string str;
                        os_mtx->lock();
                        while(getline(ifs, str))
                            eos << str << std::endl;
                        os_mtx->unlock();
                        ifs.close();

                        Path("./", output_filename).removePath();

                        if(result)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": @system(" << quote(sys_call) << ") failed" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }
                    }
                }
                else if(inLine.substr(linePos, 14) == "@systemoutput(" || inLine.substr(linePos, 15) == "@systemoutput*(")
                {
                    linePos+=std::string("@systemoutput").length();
                    std::string sys_call;
                    std::string output_filename = ".@systemoutput" + std::to_string(sys_counter++);

                    if(inLine[linePos] == '*')
                    {
                        parseParams = 1;
                        linePos++;
                    }
                    else
                        parseParams = 0;

                    linePos++;

                    if(read_sys_call(sys_call, linePos, inLine, readPath, lineNo, "@systemoutput()", eos) > 0)
                        return 1;

                    if(parseParams)
                    {
                        std::istringstream iss(sys_call);
                        oss.str("");
                        oss.clear();

                        if(read_and_process(0, iss, Path("", "system call"), antiDepsOfReadPath, oss, eos) > 0)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }

                        sys_call = oss.str();
                    }

                    #if defined _WIN32 || defined _WIN64
                        if(unquote(sys_call).substr(0, 2) == "./")
                            sys_call = unquote(sys_call).substr(2, unquote(sys_call).size()-2);
                    #else  //unix
                    #endif

                    //checks whether we're running from flatpak
                    if(std::ifstream("/.flatpak-info"))
                    {
                        //need sys_call quoted here for cURL to work
                        if(system(("flatpak-spawn --host bash -c " + quote(sys_call) + " > " + output_filename).c_str()))
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": @systemoutput(" << quote(sys_call) << ") failed" << std::endl;
                            eos << "       see " << quote(output_filename) << " for pre-error system output" << std::endl;
                            os_mtx->unlock();
                            //Path("./", output_filename).removePath();
                            return 1;
                        }
                    }
                    else if(system((sys_call + " > " + output_filename).c_str())) //sys_call has to be unquoted for cURL to work
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": @systemoutput(" << quote(sys_call) << ") failed" << std::endl;
                        eos << "       see " << quote(output_filename) << " for pre-error system output" << std::endl;
                        os_mtx->unlock();
                        //Path("./", output_filename).removePath();
                        return 1;
                    }

                    std::ifstream ifs(output_filename);

                    //indent amount updated inside read_and_process
                    if(read_and_process(1, ifs, Path("", output_filename), antiDepsOfReadPath, os, eos) > 0)
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": failed to process output of system call '" << sys_call << "'" << std::endl;
                        os_mtx->unlock();
                        //Path("./", output_filename).removePath();
                        return 1;
                    }

                    ifs.close();

                    Path("./", output_filename).removePath();
                }
                else if(inLine.substr(linePos, 15) == "@systemcontent(" || inLine.substr(linePos, 16) == "@systemcontent*(")
                {
                    linePos+=std::string("@systemcontent").length();
                    std::string sys_call;
                    std::string output_filename = ".@systemcontent" + std::to_string(sys_counter++);

                    if(inLine[linePos] == '*')
                    {
                        parseParams = 1;
                        linePos++;
                    }
                    else
                        parseParams = 0;

                    linePos++;

                    if(read_sys_call(sys_call, linePos, inLine, readPath, lineNo, "@systemcontent()", eos) > 0)
                        return 1;

                    if(parseParams)
                    {
                        std::istringstream iss(sys_call);
                        oss.str("");
                        oss.clear();

                        if(read_and_process(0, iss, Path("", "system content call"), antiDepsOfReadPath, oss, eos) > 0)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }

                        sys_call = oss.str();
                    }

                    #if defined _WIN32 || defined _WIN64
                        if(unquote(sys_call).substr(0, 2) == "./")
                            sys_call = unquote(sys_call).substr(2, unquote(sys_call).size()-2);
                    #else  //unix
                    #endif

                    contentAdded = 1;
                    sys_call += " " + quote(pageToBuild.contentPath.str());

                    //checks whether we're running from flatpak
                    if(std::ifstream("/.flatpak-info"))
                    {
                        //need sys_call quoted here for cURL to work
                        if(system(("flatpak-spawn --host bash -c " + quote(sys_call) + " > " + output_filename).c_str()))
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": @systemcontent(" << quote(sys_call) << ") failed" << std::endl;
                            eos << "       see " << quote(output_filename) << " for pre-error system output" << std::endl;
                            os_mtx->unlock();
                            //Path("./", output_filename).removePath();
                            return 1;
                        }
                    }
                    else if(system((sys_call + " > " + output_filename).c_str())) //sys_call has to be unquoted for cURL to work
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": @systemcontent(" << quote(sys_call) << ") failed" << std::endl;
                        eos << "       see " << quote(output_filename) << " for pre-error system output" << std::endl;
                        os_mtx->unlock();
                        //Path("./", output_filename).removePath();
                        return 1;
                    }

                    std::ifstream ifs(output_filename);

                    //indent amount updated inside read_and_process
                    if(read_and_process(1, ifs, Path("", output_filename), antiDepsOfReadPath, os, eos) > 0)
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": failed to process output of system call '" << sys_call << "'" << std::endl;
                        os_mtx->unlock();
                        //Path("./", output_filename).removePath();
                        return 1;
                    }

                    ifs.close();

                    Path("./", output_filename).removePath();
                }
                else if(inLine.substr(linePos,11) == "@stringdef(" || inLine.substr(linePos,12) == "@stringdef*(")
                {
                    linePos+=std::string("@stringdef").length();
                    std::string varName, varVal;

                    if(inLine[linePos] == '*')
                    {
                        parseParams = 1;
                        linePos++;
                    }
                    else
                        parseParams = 0;

                    linePos++;

                    if(read_stringdef(varName, varVal, linePos, inLine, readPath, lineNo, "@stringdef()", eos))
                        return 1;

                    if(parseParams)
                    {
                        std::istringstream iss(varName);
                        oss.str("");
                        oss.clear();

                        if(read_and_process(0, iss, Path("", "variable name"), antiDepsOfReadPath, oss, eos) > 0)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }

                        varName = oss.str();

                        iss = std::istringstream(varVal);
                        oss.str("");
                        oss.clear();

                        if(read_and_process(0, iss, Path("", "variable value"), antiDepsOfReadPath, oss, eos) > 0)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }

                        varVal = oss.str();
                    }

                    if(strings.count(varName))
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": redeclaration of string('" << varName << "')" << std::endl;
                        os_mtx->unlock();
                        return 1;
                    }
                    else
                        strings[varName] = varVal;
                }
                else if(inLine.substr(linePos, 8) == "@string(" || inLine.substr(linePos, 9) == "@string*(")
                {
                    linePos+=std::string("@string").length();
                    std::string varName;

                    if(inLine[linePos] == '*')
                    {
                        parseParams = 1;
                        linePos++;
                    }
                    else
                        parseParams = 0;

                    linePos++;

                    if(read_var(varName, linePos, inLine, readPath, lineNo, "@string()", eos))
                        return 1;

                    if(parseParams)
                    {
                        std::istringstream iss(varName);
                        oss.str("");
                        oss.clear();

                        if(read_and_process(0, iss, Path("", "variable name"), antiDepsOfReadPath, oss, eos) > 0)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }

                        varName = oss.str();
                    }

                    if(strings.count(varName))
                    {
                        os << strings[varName];
                        if(indent)
                            indentAmount += into_whitespace(strings[varName]);
                    }
                    else
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": string('" << varName << "') was not declared in this scope" << std::endl;
                        os_mtx->unlock();
                        return 1;
                    }
                }
                else if(inLine.substr(linePos, 8) == "@pathto(" || inLine.substr(linePos, 9) == "@pathto*(")
                {
                    linePos+=std::string("@pathto").length();
                    Name targetPageName;

                    if(inLine[linePos] == '*')
                    {
                        parseParams = 1;
                        linePos++;
                    }
                    else
                        parseParams = 0;

                    linePos++;

                    if(read_path(targetPageName, linePos, inLine, readPath, lineNo, "@pathto()", eos) > 0)
                        return 1;

                    if(parseParams)
                    {
                        std::istringstream iss(targetPageName);
                        oss.str("");
                        oss.clear();

                        if(read_and_process(0, iss, Path("", "@pathto path"), antiDepsOfReadPath, oss, eos) > 0)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }

                        targetPageName = oss.str();
                    }

                    //throws error if target targetPageName isn't being tracked by Nift
                    PageInfo targetPageInfo;
                    targetPageInfo.pageName = targetPageName;
                    if(!pages->count(targetPageInfo))
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": @pathto(" << targetPageName << ") failed, Nift not tracking " << targetPageName << std::endl;
                        os_mtx->unlock();
                        return 1;
                    }


                    Path targetPath = pages->find(targetPageInfo)->pagePath;
                    //targetPath.set_file_path_from(targetPathStr);

                    Path pathToTarget(pathBetween(pageToBuild.pagePath.dir, targetPath.dir), targetPath.file);

                    //adds path to target
                    os << pathToTarget.str();
                    if(indent)
                        indentAmount += into_whitespace(pathToTarget.str());
                }
                else if(inLine.substr(linePos, 12) == "@pathtopage(" || inLine.substr(linePos, 13) == "@pathtopage*(")
                {
                    linePos+=std::string("@pathtopage").length();
                    Name targetPageName;

                    if(inLine[linePos] == '*')
                    {
                        parseParams = 1;
                        linePos++;
                    }
                    else
                        parseParams = 0;

                    linePos++;

                    if(read_path(targetPageName, linePos, inLine, readPath, lineNo, "@pathtopage()", eos) > 0)
                        return 1;

                    if(parseParams)
                    {
                        std::istringstream iss(targetPageName);
                        oss.str("");
                        oss.clear();

                        if(read_and_process(0, iss, Path("", "@pathtopage path"), antiDepsOfReadPath, oss, eos) > 0)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }

                        targetPageName = oss.str();
                    }

                    //throws error if target targetPageName isn't being tracked by Nift
                    PageInfo targetPageInfo;
                    targetPageInfo.pageName = targetPageName;
                    if(!pages->count(targetPageInfo))
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": @pathtopage(" << targetPageName << ") failed, Nift not tracking " << targetPageName << std::endl;
                        os_mtx->unlock();
                        return 1;
                    }


                    Path targetPath = pages->find(targetPageInfo)->pagePath;
                    //targetPath.set_file_path_from(targetPathStr);

                    Path pathToTarget(pathBetween(pageToBuild.pagePath.dir, targetPath.dir), targetPath.file);

                    //adds path to target
                    os << pathToTarget.str();
                    if(indent)
                        indentAmount += into_whitespace(pathToTarget.str());
                }
                else if(inLine.substr(linePos, 12) == "@pathtofile(" || inLine.substr(linePos, 13) == "@pathtofile*(")
                {
                    linePos+=std::string("@pathtofile").length();
                    Name targetFilePath;

                    if(inLine[linePos] == '*')
                    {
                        parseParams = 1;
                        linePos++;
                    }
                    else
                        parseParams = 0;

                    linePos++;

                    if(read_path(targetFilePath, linePos, inLine, readPath, lineNo, "@pathtofile()", eos) > 0)
                        return 1;

                    if(parseParams)
                    {
                        std::istringstream iss(targetFilePath);
                        oss.str("");
                        oss.clear();

                        if(read_and_process(0, iss, Path("", "@pathtofile path"), antiDepsOfReadPath, oss, eos) > 0)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }

                        targetFilePath = oss.str();
                    }

                    //throws error if targetFilePath doesn't exist
                    if(!std::ifstream(targetFilePath.c_str()))
                    {
                        os_mtx->lock();
                        eos << "error: " << readPath << ": line " << lineNo << ": file " << targetFilePath << " does not exist" << std::endl;
                        os_mtx->unlock();
                        return 1;
                    }
                    Path targetPath;
                    targetPath.set_file_path_from(targetFilePath);

                    Path pathToTarget(pathBetween(pageToBuild.pagePath.dir, targetPath.dir), targetPath.file);

                    //adds path to target
                    os << pathToTarget.str();
                    if(indent)
                        indentAmount += into_whitespace(pathToTarget.str());
                }
                else if(inLine.substr(linePos, 10) == "@pagetitle")
                {
                    os << pageToBuild.pageTitle.str;
                    if(indent)
                        indentAmount += into_whitespace(pageToBuild.pageTitle.str);
                    linePos += std::string("@pagetitle").length();
                }
                else if(inLine.substr(linePos, 11) == "@page-title")
                {
                    os << pageToBuild.pageTitle.str;
                    if(indent)
                        indentAmount += into_whitespace(pageToBuild.pageTitle.str);
                    linePos += std::string("@page-title").length();
                }
                else if(inLine.substr(linePos, 9) == "@pagename")
                {
                    os << pageToBuild.pageName;
                    if(indent)
                        indentAmount += into_whitespace(pageToBuild.pageName);
                    linePos += std::string("@pagename").length();
                }
                else if(inLine.substr(linePos, 9) == "@pagepath")
                {
                    os << pageToBuild.pagePath.str();
                    if(indent)
                        indentAmount += into_whitespace(pageToBuild.pagePath.str());
                    linePos += std::string("@pagepath").length();
                }
                else if(inLine.substr(linePos, 12) == "@contentpath")
                {
                    os << pageToBuild.contentPath.str();
                    if(indent)
                        indentAmount += into_whitespace(pageToBuild.contentPath.str());
                    linePos += std::string("@contentpath").length();
                }
                else if(inLine.substr(linePos, 13) == "@templatepath")
                {
                    os << pageToBuild.templatePath.str();
                    if(indent)
                        indentAmount += into_whitespace(pageToBuild.templatePath.str());
                    linePos += std::string("@templatepath").length();
                }
                else if(inLine.substr(linePos, 13) == "@contentdir")
                {
                    os << contentDir;
                    if(indent)
                        indentAmount += into_whitespace(contentDir);
                    linePos += std::string("@contentdir").length();
                }
                else if(inLine.substr(linePos, 13) == "@contentext")
                {
                    os << contentExt;
                    if(indent)
                        indentAmount += into_whitespace(contentExt);
                    linePos += std::string("@contentext").length();
                }
                else if(inLine.substr(linePos, 8) == "@pageext")
                {
                    os << pageExt;
                    if(indent)
                        indentAmount += into_whitespace(pageExt);
                    linePos += std::string("@pageExt").length();
                }
                else if(inLine.substr(linePos, 16) == "@defaulttemplate")
                {
                    os << defaultTemplate.str();
                    if(indent)
                        indentAmount += into_whitespace(defaultTemplate.str());
                    linePos += std::string("@defaulttemplate").length();
                }
                else if(inLine.substr(linePos, 13) == "@sitedir")
                {
                    os << siteDir;
                    if(indent)
                        indentAmount += into_whitespace(siteDir);
                    linePos += std::string("@sitedir").length();
                }
                else if(inLine.substr(linePos, 14) == "@buildtimezone")
                {
                    os << dateTimeInfo.cTimezone;
                    if(indent)
                        indentAmount += into_whitespace(dateTimeInfo.cTimezone);
                    linePos += std::string("@buildtimezone").length();
                }
                else if(inLine.substr(linePos, 13) == "@loadtimezone")
                {
                    os << "<script>document.write(new Date().toString().split(\"(\")[1].split(\")\")[0])</script>";
                    if(indent)
                        indentAmount += std::string(82, ' ');
                    linePos += std::string("@loadtimezone").length();
                }
                else if(inLine.substr(linePos, 9) == "@timezone")
                { //this is left for backwards compatibility
                    os << dateTimeInfo.cTimezone;
                    if(indent)
                        indentAmount += into_whitespace(dateTimeInfo.cTimezone);
                    linePos += std::string("@timezone").length();
                }
                else if(inLine.substr(linePos, 10) == "@buildtime")
                {
                    os << dateTimeInfo.cTime;
                    if(indent)
                        indentAmount += into_whitespace(dateTimeInfo.cTime);
                    linePos += std::string("@buildtime").length();
                }
                else if(inLine.substr(linePos, 13) == "@buildUTCtime")
                {
                    os << dateTimeInfo.currentUTCTime();
                    if(indent)
                        indentAmount += into_whitespace(dateTimeInfo.currentUTCTime());
                    linePos += std::string("@buildUTCtime").length();
                }
                else if(inLine.substr(linePos, 10) == "@builddate")
                {
                    os << dateTimeInfo.cDate;
                    if(indent)
                        indentAmount += into_whitespace(dateTimeInfo.cDate);
                    linePos += std::string("@builddate").length();
                }
                else if(inLine.substr(linePos, 13) == "@buildUTCdate")
                {
                    os << dateTimeInfo.currentUTCDate();
                    if(indent)
                        indentAmount += into_whitespace(dateTimeInfo.currentUTCDate());
                    linePos += std::string("@buildUTCdate").length();
                }
                else if(inLine.substr(linePos, 12) == "@currenttime")
                { //this is left for backwards compatibility
                    os << dateTimeInfo.cTime;
                    if(indent)
                        indentAmount += into_whitespace(dateTimeInfo.cTime);
                    linePos += std::string("@currenttime").length();
                }
                else if(inLine.substr(linePos, 15) == "@currentUTCtime")
                { //this is left for backwards compatibility
                    os << dateTimeInfo.currentUTCTime();
                    if(indent)
                        indentAmount += into_whitespace(dateTimeInfo.currentUTCTime());
                    linePos += std::string("@currentUTCtime").length();
                }
                else if(inLine.substr(linePos, 12) == "@currentdate")
                { //this is left for backwards compatibility
                    os << dateTimeInfo.cDate;
                    if(indent)
                        indentAmount += into_whitespace(dateTimeInfo.cDate);
                    linePos += std::string("@currentdate").length();
                }
                else if(inLine.substr(linePos, 15) == "@currentUTCdate")
                { //this is left for backwards compatibility
                    os << dateTimeInfo.currentUTCDate();
                    if(indent)
                        indentAmount += into_whitespace(dateTimeInfo.currentUTCDate());
                    linePos += std::string("@currentUTCdate").length();
                }
                else if(inLine.substr(linePos, 9) == "@loadtime")
                {
                    os << "<script>document.write((new Date().toLocaleString()).split(\",\")[1])</script>";
                    if(indent)
                        indentAmount += std::string(76, ' ');
                    linePos += std::string("@loadtime").length();
                }
                else if(inLine.substr(linePos, 12) == "@loadUTCtime")
                {
                    os << "<script>document.write((new Date().toISOString()).split(\"T\")[1].split(\".\")[0])</script>";
                    if(indent)
                        indentAmount += std::string(87, ' ');
                    linePos += std::string("@loadUTCtime").length();
                }
                else if(inLine.substr(linePos, 9) == "@loaddate")
                {
                    os << "<script>document.write((new Date().toLocaleString()).split(\",\")[0])</script>";
                    if(indent)
                        indentAmount += std::string(76, ' ');
                    linePos += std::string("@loaddate").length();
                }
                else if(inLine.substr(linePos, 12) == "@loadUTCdate")
                {
                    os << "<script>document.write((new Date().toISOString()).split(\"T\")[0])</script>";
                    if(indent)
                        indentAmount += std::string(73, ' ');
                    linePos += std::string("@loadUTCdate").length();
                }
                else if(inLine.substr(linePos, 10) == "@buildYYYY")
                {
                    os << dateTimeInfo.currentYYYY();
                    if(indent)
                        indentAmount += into_whitespace(dateTimeInfo.currentYYYY());
                    linePos += std::string("@buildYYYY").length();
                }
                else if(inLine.substr(linePos, 8) == "@buildYY")
                {
                    os << dateTimeInfo.currentYY();
                    if(indent)
                        indentAmount += into_whitespace(dateTimeInfo.currentYY());
                    linePos += std::string("@buildYY").length();
                }
                else if(inLine.substr(linePos, 12) == "@currentYYYY")
                { //this is left for backwards compatibility
                    os << dateTimeInfo.currentYYYY();
                    if(indent)
                        indentAmount += into_whitespace(dateTimeInfo.currentYYYY());
                    linePos += std::string("@currentYYYY").length();
                }
                else if(inLine.substr(linePos, 10) == "@currentYY")
                { //this is left for backwards compatibility
                    os << dateTimeInfo.currentYY();
                    if(indent)
                        indentAmount += into_whitespace(dateTimeInfo.currentYY());
                    linePos += std::string("@currentYY").length();
                }
                else if(inLine.substr(linePos, 9) == "@loadYYYY")
                {
                    os << "<script>document.write(new Date().getFullYear())</script>";
                    if(indent)
                        indentAmount += std::string(57, ' ');
                    linePos += std::string("@loadYYYY").length();
                }
                else if(inLine.substr(linePos, 7) == "@loadYY")
                {
                    os << "<script>document.write(new Date().getFullYear()%100)</script>";
                    if(indent)
                        indentAmount += std::string(61, ' ');
                    linePos += std::string("@loadYY").length();
                }
                else if(inLine.substr(linePos, 8) == "@buildOS")
                {
                    os << dateTimeInfo.currentOS();
                    if(indent)
                        indentAmount += into_whitespace(dateTimeInfo.currentOS());
                    linePos += std::string("@buildOS").length();
                }
                else if(inLine.substr(linePos, 10) == "@currentOS")
                { //this is left for backwards compatibility
                    os << dateTimeInfo.currentOS();
                    if(indent)
                        indentAmount += into_whitespace(dateTimeInfo.currentOS());
                    linePos += std::string("@currentOS").length();
                } //I'm not sure how to do loadOS sorry!
                else if(inLine.substr(linePos, 16) == "@faviconinclude(" || inLine.substr(linePos, 17) == "@faviconinclude*(") //checks for favicon include
                {
                    linePos+=std::string("@faviconinclude").length();
                    std::string faviconPathStr;

                    if(inLine[linePos] == '*')
                    {
                        parseParams = 1;
                        linePos++;
                    }
                    else
                        parseParams = 0;

                    linePos++;

                    if(read_path(faviconPathStr, linePos, inLine, readPath, lineNo, "@faviconinclude()", eos) > 0)
                        return 1;

                    if(parseParams)
                    {
                        std::istringstream iss(faviconPathStr);
                        oss.str("");
                        oss.clear();

                        if(read_and_process(0, iss, Path("", "favicon path"), antiDepsOfReadPath, oss, eos) > 0)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }

                        faviconPathStr = oss.str();
                    }

                    //warns user if favicon file doesn't exist
                    if(!std::ifstream(faviconPathStr.c_str()))
                    {
                        os_mtx->lock();
                        eos << "warning: " << readPath << ": line " << lineNo << ": favicon file " << faviconPathStr << " does not exist" << std::endl;
                        os_mtx->unlock();
                    }

                    Path faviconPath;
                    faviconPath.set_file_path_from(faviconPathStr);

                    Path pathToFavicon(pathBetween(pageToBuild.pagePath.dir, faviconPath.dir), faviconPath.file);

                    std::string faviconInclude = "<link rel='icon' type='image/png' href='";
                    faviconInclude += pathToFavicon.str();
                    faviconInclude += "'>";

                    os << faviconInclude;
                    if(indent)
                        indentAmount += into_whitespace(faviconInclude);
                }
                else if(inLine.substr(linePos, 12) == "@cssinclude(" || inLine.substr(linePos, 13) == "@cssinclude*(") //checks for css includes
                {
                    linePos+=std::string("@cssinclude").length();
                    std::string cssPathStr;

                    if(inLine[linePos] == '*')
                    {
                        parseParams = 1;
                        linePos++;
                    }
                    else
                        parseParams = 0;

                    linePos++;

                    if(read_path(cssPathStr, linePos, inLine, readPath, lineNo, "@cssinclude()", eos) > 0)
                        return 1;

                    if(parseParams)
                    {
                        std::istringstream iss(cssPathStr);
                        oss.str("");
                        oss.clear();

                        if(read_and_process(0, iss, Path("", "css file path"), antiDepsOfReadPath, oss, eos) > 0)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }

                        cssPathStr = oss.str();
                    }

                    //warns user if css file doesn't exist
                    if(!std::ifstream(cssPathStr.c_str()))
                    {
                        os_mtx->lock();
                        eos << "warning: " << readPath << ": line " << lineNo << ": css file " << cssPathStr << " does not exist" << std::endl;
                        os_mtx->unlock();
                    }

                    Path cssPath;
                    cssPath.set_file_path_from(cssPathStr);

                    Path pathToCSSFile(pathBetween(pageToBuild.pagePath.dir, cssPath.dir), cssPath.file);

                    std::string cssInclude = "<link rel='stylesheet' type='text/css' href='";
                    cssInclude += pathToCSSFile.str();
                    cssInclude += "'>";

                    os << cssInclude;
                    if(indent)
                        indentAmount += into_whitespace(cssInclude);
                }
                else if(inLine.substr(linePos, 12) == "@imginclude(" || inLine.substr(linePos, 13) == "@imginclude*(") //checks for img includes
                {
                    linePos+=std::string("@imginclude").length();
                    std::string imgPathStr;

                    if(inLine[linePos] == '*')
                    {
                        parseParams = 1;
                        linePos++;
                    }
                    else
                        parseParams = 0;

                    linePos++;

                    if(read_path(imgPathStr, linePos, inLine, readPath, lineNo, "@imginclude()", eos) > 0)
                        return 1;

                    if(parseParams)
                    {
                        std::istringstream iss(imgPathStr);
                        oss.str("");
                        oss.clear();

                        if(read_and_process(0, iss, Path("", "image file path"), antiDepsOfReadPath, oss, eos) > 0)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }

                        imgPathStr = oss.str();
                    }

                    //warns user if img file doesn't exist
                    if(!std::ifstream(imgPathStr.c_str()))
                    {
                        os_mtx->lock();
                        eos << "warning: " << readPath << ": line " << lineNo << ": img file " << imgPathStr << " does not exist" << std::endl;
                        os_mtx->unlock();
                    }

                    Path imgPath;
                    imgPath.set_file_path_from(imgPathStr);

                    Path pathToIMGFile(pathBetween(pageToBuild.pagePath.dir, imgPath.dir), imgPath.file);

                    std::string imgInclude = "<img src=\"" + pathToIMGFile.str() + "\">";

                    os << imgInclude;
                    if(indent)
                        indentAmount += into_whitespace(imgInclude);
                }
                else if(inLine.substr(linePos, 11) == "@jsinclude(" || inLine.substr(linePos, 12) == "@jsinclude*(") //checks for js includes
                {
                    linePos+=std::string("@jsinclude").length();
                    std::string jsPathStr;

                    if(inLine[linePos] == '*')
                    {
                        parseParams = 1;
                        linePos++;
                    }
                    else
                        parseParams = 0;

                    linePos++;

                    if(read_path(jsPathStr, linePos, inLine, readPath, lineNo, "@jsinclude()", eos) > 0)
                        return 1;

                    if(parseParams)
                    {
                        std::istringstream iss(jsPathStr);
                        oss.str("");
                        oss.clear();

                        if(read_and_process(0, iss, Path("", "javascript file path"), antiDepsOfReadPath, oss, eos) > 0)
                        {
                            os_mtx->lock();
                            eos << "error: " << readPath << ": line " << lineNo << ": read_and_process() failed here" << std::endl;
                            os_mtx->unlock();
                            return 1;
                        }

                        jsPathStr = oss.str();
                    }

                    //warns user if js file doesn't exist
                    if(!std::ifstream(jsPathStr.c_str()))
                    {
                        os_mtx->lock();
                        eos << "warning: " << readPath << ": line " << lineNo << ": js file " << jsPathStr << " does not exist" << std::endl;
                        os_mtx->unlock();
                    }

                    Path jsPath;
                    jsPath.set_file_path_from(jsPathStr);

                    Path pathToJSFile(pathBetween(pageToBuild.pagePath.dir, jsPath.dir), jsPath.file);

                    //the type attribute is unnecessary for JavaScript resources.
                    //std::string jsInclude="<script type='text/javascript' src='";
                    std::string jsInclude="<script src='";
                    jsInclude += pathToJSFile.str();
                    jsInclude+="'></script>";

                    os << jsInclude;
                    if(indent)
                        indentAmount += into_whitespace(jsInclude);
                }
                else
                {
                    os << '@';
                    if(indent)
                        indentAmount += " ";
                    linePos++;
                }
            }
            else //regular character
            {
                if(indent)
                {
                    if(inLine[linePos] == '\t')
                        indentAmount += '\t';
                    else
                        indentAmount += ' ';
                }
                os << inLine[linePos++];
            }
        }
    }

    if(codeBlockDepth > baseCodeBlockDepth)
    {
        os_mtx->lock();
        eos << "error: " << readPath << ": line " << openCodeLineNo << ": <pre*> open tag has no following </pre> close tag." << std::endl;
        os_mtx->unlock();
        return 1;
    }

    return 0;
}

int PageBuilder::read_path(std::string& pathRead, size_t& linePos, const std::string& inLine, const Path& readPath, const int& lineNo, const std::string& callType, std::ostream& os)
{
    pathRead = "";

    //skips over leading whitespace
    while(linePos < inLine.size() && (inLine[linePos] == ' ' || inLine[linePos] == '\t'))
        ++linePos;

    //throws error if either no closing bracket or a newline
    if(linePos == inLine.size())
    {
        os_mtx->lock();
        os << "error: " << readPath << ": line " << lineNo << ": path has no closing bracket ) or newline inside " << callType << " call" << std::endl;
        os_mtx->unlock();
        return 1;
    }

    //throws error if no path provided
    if(inLine[linePos] == ')')
    {
        os_mtx->lock();
        os << "error: " << readPath << ": line " << lineNo << ": no path provided inside " << callType << " call" << std::endl;
        os_mtx->unlock();
        return 1;
    }

    //reads the input path
    if(inLine[linePos] == '\'')
    {
        ++linePos;
        for(; inLine[linePos] != '\''; ++linePos)
        {
            if(linePos == inLine.size())
            {
                os_mtx->lock();
                os << "error: " << readPath << ": line " << lineNo << ": path has no closing single quote or newline inside " << callType << " call" << std::endl;
                os_mtx->unlock();
                return 1;
            }
            pathRead += inLine[linePos];
        }
        ++linePos;
    }
    else if(inLine[linePos] == '"')
    {
        ++linePos;
        for(; inLine[linePos] != '"'; ++linePos)
        {
            if(linePos == inLine.size())
            {
                os_mtx->lock();
                os << "error: " << readPath << ": line " << lineNo << ": path has no closing double quote \" or newline inside " << callType << " call" << std::endl;
                os_mtx->unlock();
                return 1;
            }
            pathRead += inLine[linePos];
        }
        ++linePos;
    }
    else
    {
        //reads path value
        for(; inLine[linePos] != ')' && inLine[linePos] != ' ' && inLine[linePos] != '\t'; ++linePos)
        {
            if(linePos == inLine.size())
            {
                os_mtx->lock();
                os << "error: " << readPath << ": line " << lineNo << ": path has no closing bracket ) or newline inside " << callType << " call" << std::endl;
                os_mtx->unlock();
                return 1;
            }
            pathRead += inLine[linePos];
        }
    }

    //skips over hopefully trailing whitespace
    while(linePos < inLine.size() && (inLine[linePos] == ' ' || inLine[linePos] == '\t'))
        ++linePos;

    //throws error if new line is between the path and close bracket
    if(linePos == inLine.size())
    {
        os_mtx->lock();
        os << "error: " << readPath << ": line " << lineNo << ": path has no closing bracket ) or newline inside " << callType << " call" << std::endl;
        os_mtx->unlock();
        return 1;
    }

    //throws error if the path is invalid
    if(inLine[linePos] != ')')
    {
        os_mtx->lock();
        os << "error: " << readPath << ": line " << lineNo << ": invalid path inside " << callType << " call" << std::endl;
        os_mtx->unlock();
        return 1;
    }

    ++linePos;

    return 0;
}

int PageBuilder::read_sys_call(std::string& sys_call, size_t& linePos, const std::string& inLine, const Path& readPath, const int& lineNo, const std::string& callType, std::ostream& os)
{
    sys_call = "";

    //skips over leading whitespace
    while(linePos < inLine.size() && (inLine[linePos] == ' ' || inLine[linePos] == '\t'))
        ++linePos;

    //throws error if either no closing bracket or a newline
    if(linePos == inLine.size())
    {
        os_mtx->lock();
        os << "error: " << readPath << ": line " << lineNo << ": system call has no closing bracket ) or newline inside " << callType << " call" << std::endl;
        os_mtx->unlock();
        return 1;
    }

    //throws error if no system call provided
    if(inLine[linePos] == ')')
    {
        os_mtx->lock();
        os << "error: " << readPath << ": line " << lineNo << ": no system call provided inside " << callType << " call" << std::endl;
        os_mtx->unlock();
        return 1;
    }

    //reads the input system call
    if(inLine[linePos] == '\'')
    {
        ++linePos;
        for(; inLine[linePos] != '\''; ++linePos)
        {
            if(linePos == inLine.size())
            {
                os_mtx->lock();
                os << "error: " << readPath << ": line " << lineNo << ": system call has no closing single quote or newline inside " << callType << " call" << std::endl;
                os_mtx->unlock();
                return 1;
            }
            else if(inLine[linePos] == '\\' && linePos+1 < inLine.size() && inLine[linePos+1] == '\'')
                linePos++;
            else if(inLine[linePos] == '\\' && linePos+1 < inLine.size() && inLine[linePos+1] == '"')
                linePos++;
            sys_call += inLine[linePos];
        }
        ++linePos;
    }
    else if(inLine[linePos] == '"')
    {
        ++linePos;
        for(; inLine[linePos] != '"'; ++linePos)
        {
            if(linePos == inLine.size())
            {
                os_mtx->lock();
                os << "error: " << readPath << ": line " << lineNo << ": system call has no closing double quote \" or newline inside " << callType << " call" << std::endl;
                os_mtx->unlock();
                return 1;
            }
            else if(inLine[linePos] == '\\' && linePos+1 < inLine.size() && inLine[linePos+1] == '\'')
                linePos++;
            else if(inLine[linePos] == '\\' && linePos+1 < inLine.size() && inLine[linePos+1] == '"')
                linePos++;
            sys_call += inLine[linePos];
        }
        ++linePos;
    }
    else
    {
        for(; inLine[linePos] != ')' && inLine[linePos] != ' ' && inLine[linePos] != '\t'; ++linePos)
        {
            if(linePos == inLine.size())
            {
                os_mtx->lock();
                os << "error: " << readPath << ": line " << lineNo << ": system call has no closing bracket ) or newline inside " << callType << " call" << std::endl;
                os_mtx->unlock();
                return 1;
            }
            else if(inLine[linePos] == '\\' && linePos+1 < inLine.size() && inLine[linePos+1] == '\'')
                linePos++;
            else if(inLine[linePos] == '\\' && linePos+1 < inLine.size() && inLine[linePos+1] == '"')
                linePos++;
            sys_call += inLine[linePos];
        }
    }

    //skips over hopefully trailing whitespace
    while(linePos < inLine.size() && (inLine[linePos] == ' ' || inLine[linePos] == '\t'))
        ++linePos;

    //throws error if new line is between the system call and close bracket
    if(linePos == inLine.size())
    {
        os_mtx->lock();
        os << "error: " << readPath << ": line " << lineNo << ": system call has no closing bracket ) or newline inside " << callType << " call" << std::endl;
        os_mtx->unlock();
        return 1;
    }

    //throws error if the system call is invalid (eg. has text after quoted system call)
    if(inLine[linePos] != ')')
    {
        os_mtx->lock();
        os << "error: " << readPath << ": line " << lineNo << ": invalid system call inside " << callType << " call" << std::endl;
        os_mtx->unlock();
        return 1;
    }

    ++linePos;

    return 0;
}

int PageBuilder::read_stringdef(std::string& varName, std::string& varVal, size_t& linePos, const std::string& inLine, const Path& readPath, const int& lineNo, const std::string& callType, std::ostream& os)
{
    varName = varVal = "";

    //skips over leading whitespace
    while(linePos < inLine.size() && (inLine[linePos] == ' ' || inLine[linePos] == '\t'))
        ++linePos;

    //throws error if either no closing bracket or a newline or no variable definition
    if(linePos == inLine.size() || inLine[linePos] == ')')
    {
        os_mtx->lock();
        os << "error: " << readPath << ": line " << lineNo << ": no variable definition provided inside " << callType << " call" << std::endl;
        os_mtx->unlock();
        return 1;
    }

    //reads variable name
    for(; inLine[linePos] != ')' && inLine[linePos] != '=' && inLine[linePos] != ' ' && inLine[linePos] != '\t'; ++linePos)
    {
        if(linePos == inLine.size())
        {
            os_mtx->lock();
            os << "error: " << readPath << ": line " << lineNo << ": variable definition has no closing bracket ) or newline inside " << callType << " call" << std::endl;
            os_mtx->unlock();
            return 1;
        }
        else if(inLine[linePos] == '\\' && linePos+1 < inLine.size() && inLine[linePos+1] == '\'')
            linePos++;
        else if(inLine[linePos] == '\\' && linePos+1 < inLine.size() && inLine[linePos+1] == '"')
            linePos++;
        varName += inLine[linePos];
    }

    //skips over whitespace
    while(linePos < inLine.size() && (inLine[linePos] == ' ' || inLine[linePos] == '\t'))
        ++linePos;

    if(linePos == inLine.size() || inLine[linePos] == ')')
    {
        os_mtx->lock();
        os << "error: " << readPath << ": line " << lineNo << ": incomplete variable definition inside " << callType << " call" << std::endl;
        os_mtx->unlock();
        return 1;
    }
    else if(inLine[linePos] != '=')
    {
        os_mtx->lock();
        os << "error: " << readPath << ": line " << lineNo << ": variable definition has no = between variable name and value inside " << callType << " call" << std::endl;
        os_mtx->unlock();
        return 1;
    }

    linePos++;

    //skips over whitespace
    while(linePos < inLine.size() && (inLine[linePos] == ' ' || inLine[linePos] == '\t'))
        ++linePos;

    if(linePos == inLine.size() || inLine[linePos] == ')')
    {
        os_mtx->lock();
        os << "error: " << readPath << ": line " << lineNo << ": incomplete variable definition inside " << callType << " call" << std::endl;
        os_mtx->unlock();
        return 1;
    }

    //reads the variable value
    if(inLine[linePos] == '\'')
    {
        ++linePos;
        for(; inLine[linePos] != '\''; ++linePos)
        {
            if(linePos == inLine.size())
            {
                os_mtx->lock();
                os << "error: " << readPath << ": line " << lineNo << ": variable definition has no closing single quote or newline inside " << callType << " call" << std::endl;
                os_mtx->unlock();
                return 1;
            }
            else if(inLine[linePos] == '\\' && linePos+1 < inLine.size() && inLine[linePos+1] == '\'')
                linePos++;
            else if(inLine[linePos] == '\\' && linePos+1 < inLine.size() && inLine[linePos+1] == '"')
                linePos++;
            varVal += inLine[linePos];
        }
        ++linePos;
    }
    else if(inLine[linePos] == '"')
    {
        ++linePos;
        for(; inLine[linePos] != '"'; ++linePos)
        {
            if(linePos == inLine.size())
            {
                os_mtx->lock();
                os << "error: " << readPath << ": line " << lineNo << ": variable definition has no closing double quote \" or newline inside " << callType << " call" << std::endl;
                os_mtx->unlock();
                return 1;
            }
            else if(inLine[linePos] == '\\' && linePos+1 < inLine.size() && inLine[linePos+1] == '\'')
                linePos++;
            else if(inLine[linePos] == '\\' && linePos+1 < inLine.size() && inLine[linePos+1] == '"')
                linePos++;
            varVal += inLine[linePos];
        }
        ++linePos;
    }
    else
    {
        //reads variable value
        for(; inLine[linePos] != ')' && inLine[linePos] != ' ' && inLine[linePos] != '\t'; ++linePos)
        {
            if(linePos == inLine.size())
            {
                os_mtx->lock();
                os << "error: " << readPath << ": line " << lineNo << ": variable definition has no closing bracket ) or newline inside " << callType << " call" << std::endl;
                os_mtx->unlock();
                return 1;
            }
            else if(inLine[linePos] == '\\' && linePos+1 < inLine.size() && inLine[linePos+1] == '\'')
                linePos++;
            else if(inLine[linePos] == '\\' && linePos+1 < inLine.size() && inLine[linePos+1] == '"')
                linePos++;
            varVal += inLine[linePos];
        }
    }

    //skips over hopefully trailing whitespace
    while(linePos < inLine.size() && (inLine[linePos] == ' ' || inLine[linePos] == '\t'))
        ++linePos;

    //throws error if new line is between the variable definition and close bracket
    if(linePos == inLine.size())
    {
        os_mtx->lock();
        os << "error: " << readPath << ": line " << lineNo << ": variable definition has no closing bracket ) or newline inside " << callType << " call" << std::endl;
        os_mtx->unlock();
        return 1;
    }

    //throws error if the variable definition is invalid
    if(inLine[linePos] != ')')
    {
        os_mtx->lock();
        os << "error: " << readPath << ": line " << lineNo << ": invalid variable definition inside " << callType << " call" << std::endl;
        os_mtx->unlock();
        return 1;
    }

    ++linePos;

    return 0;
}

int PageBuilder::read_var(std::string& varName, size_t& linePos, const std::string& inLine, const Path& readPath, const int& lineNo, const std::string& callType, std::ostream& os)
{
    varName = "";

    //skips over leading whitespace
    while(linePos < inLine.size() && (inLine[linePos] == ' ' || inLine[linePos] == '\t'))
        ++linePos;

    //throws error if either no closing bracket or a newline or no variable name
    if(linePos == inLine.size() || inLine[linePos] == ')')
    {
        os_mtx->lock();
        os << "error: " << readPath << ": line " << lineNo << ": no variable name provided inside " << callType << " call" << std::endl;
        os_mtx->unlock();
        return 1;
    }

    //reads variable name
    for(; inLine[linePos] != ')' && inLine[linePos] != ' ' && inLine[linePos] != '\t'; ++linePos)
    {
        if(linePos == inLine.size())
        {
            os_mtx->lock();
            os << "error: " << readPath << ": line " << lineNo << ": variable name has no closing bracket ) or newline inside " << callType << " call" << std::endl;
            os_mtx->unlock();
            return 1;
        }
        else if(inLine[linePos] == '\\' && linePos+1 < inLine.size() && inLine[linePos+1] == '\'')
            linePos++;
        else if(inLine[linePos] == '\\' && linePos+1 < inLine.size() && inLine[linePos+1] == '"')
            linePos++;
        varName += inLine[linePos];
    }

    //skips over hopefully trailing whitespace
    while(linePos < inLine.size() && (inLine[linePos] == ' ' || inLine[linePos] == '\t'))
        ++linePos;

    //throws error if new line is between the variable name and close bracket
    if(linePos == inLine.size())
    {
        os_mtx->lock();
        os << "error: " << readPath << ": line " << lineNo << ": variable name has no closing bracket ) or newline inside " << callType << " call" << std::endl;
        os_mtx->unlock();
        return 1;
    }

    //throws error if the variable name is invalid
    if(inLine[linePos] != ')')
    {
        os_mtx->lock();
        os << "error: " << readPath << ": line " << lineNo << ": invalid variable name inside " << callType << " call" << std::endl;
        os_mtx->unlock();
        return 1;
    }

    ++linePos;

    return 0;
}
