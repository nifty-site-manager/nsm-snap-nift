<p align="center">
    <img src="https://gitlab.com/nifty-site-manager/nsm-snap/raw/master/nsm.png" width='120'/>
</p>

=====

Copyright (c) 2015-present [Nicholas Ham](https://n-ham.com).

This is an official (Snap) repository for nifty-site-manager, a cross-platform git-like and LaTeX-like command-line site manager.

Website:
\[[official](https://nift.cc)\] \[[bitbucket](https://nifty-site-manager.bitbucket.io)\] \[[github](https://nifty-site-manager.github.io)\] \[[gitlab](https://nifty-site-manager.gitlab.io)\] \[[Netlify](https://nifty-site-manager.netlify.com/)\]

Repositories:
\[[bitbucket](https://bitbucket.com/nifty-site-manager/nsm)\] \[[github](https://github.com/nifty-site-manager/nsm)\] \[[gitlab](https://gitlab.com/nifty-site-manager/nsm)\]

