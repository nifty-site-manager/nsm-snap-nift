## Changes

The following changes have been made to exprtk.h and should be added to any updated versions of exprtk.h to be embedded in Nift.

* instead of throwing an error when trying to add a duplicate variable to a symbol table, now removes the original variable and inserts the new one